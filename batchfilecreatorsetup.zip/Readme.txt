KaSaB Batch File creator is a freeware application developed by KaSaB Software.

It is intended to be a simple IDE to create and run batch files.  The appliaction is small and fast.

To install:
--------------------
Zip file contains Readme.txt
setup.exe

Double click on setup.exe then follow instructiion in installation wizard.

System Requirements:
--------------------
Windows 98, ME, 2000, XP or 2003.
64Mb RAM
3Mb Hard Disk Space
Microsoft Internet Explorer 5+ (for web preview)

Features:
--------------------
-  pulldown menu to select commands, with brief explaination.
- load and save batch files.
- Unlimited undo.
- run batch file from within IDE.
- print batch file including file name and date printed.
- Auto creation date insert option.

 