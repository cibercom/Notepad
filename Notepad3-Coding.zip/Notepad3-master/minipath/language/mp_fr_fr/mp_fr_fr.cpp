// encoding: UTF-8
// mp_fr_fr.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


