// encoding: UTF-8
// np3_af_za.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"


