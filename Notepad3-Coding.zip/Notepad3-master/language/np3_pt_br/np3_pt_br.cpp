// encoding: UTF-8
// np3_pt_br.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


