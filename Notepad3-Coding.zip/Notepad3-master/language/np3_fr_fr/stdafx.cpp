// encoding: UTF-8
// stdafx.cpp : Quelldatei, die nur die Standard-Includes einbindet.
// np3_fr_fr.pch ist der vorkompilierte Header.
// stdafx.obj enthält die vorkompilierten Typinformationen.

#include "stdafx.h"

// TODO: Auf zusätzliche Header verweisen, die in STDAFX.H
// und nicht in dieser Datei erforderlich sind.
