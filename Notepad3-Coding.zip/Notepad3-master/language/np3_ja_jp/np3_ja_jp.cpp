// encoding: UTF-8
// np3_ja_jp.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


