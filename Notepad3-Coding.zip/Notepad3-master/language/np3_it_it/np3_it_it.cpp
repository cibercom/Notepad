// encoding: UTF-8
// np3_it_it.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


