// encoding: UTF-8
// np3_en_uk.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


