Free JavaScript Editor
version  : 4.7
author   : Yaldex Software
www      : http://www.yaldex.com
contacts : http://www.yaldex.com/help.htm

Compatibility:
Any windows
 

Installation :
--------------
Unzip �freejse.exe� file into any directory, 
then double-click extracted file to install Free JavaScript Editor.

